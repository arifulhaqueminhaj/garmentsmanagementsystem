from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth import login as auth_login, logout as auth_logout, authenticate
from django.views.decorators.csrf import csrf_exempt 
from django.http import HttpResponse, Http404
from django.contrib.auth.models import User
from .models import Employee, Supplier, Product, Attendance
from .models import EmployeeProfile, DailyWork, Production, PaymentTransaction
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from .forms import ProductionForm, BonusForm, ProductCountForm, AttendanceEditForm
from django.db.models import Sum 
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from datetime import date, datetime
from django.template.loader import render_to_string
from io import BytesIO
from django.http import JsonResponse
import uuid
import requests
import json
from django.conf import settings
from django.urls import reverse
from django.core.mail import send_mail

# PDF generation library - imported lazily to avoid issues
pisa = None
 
# --------------------------
# Generic CRUD helper
# --------------------------
@login_required(login_url='admin_login')
def list_items(request, model, template, context_name):
    if request.user.is_authenticated and request.user.is_staff: 
        items = model.objects.all()
    return render(request, template, {context_name: items})

@login_required(login_url='admin_login')
def add_item(request, model, fields, template, redirect_url):
    if request.user.is_authenticated and request.user.is_staff: 
        if request.method == "POST":
            data = {field: request.POST[field] for field in fields}
            model.objects.create(**data)
            return redirect('admin_redirect')  
    return render(request, template)

@login_required(login_url='admin_login')
def edit_item(request, model, sl, fields, template, redirect_url):
    if request.user.is_authenticated and request.user.is_staff: 
        item = get_object_or_404(model, sl=sl)
        if request.method == "POST":
            for field in fields:
                setattr(item, field, request.POST[field])
            item.save()
            return redirect('admin_redirect')  
    return render(request, template, {model.__name__.lower(): item})

@login_required(login_url='admin_login')
def delete_item(request, model, sl, redirect_url):
    if request.user.is_authenticated and request.user.is_staff: 
        item = get_object_or_404(model, sl=sl)
        item.delete()
    return redirect('admin_redirect')  
# --------------------------
# Employee CRUD
# --------------------------
def employee_list(request):
    return list_items(request, Employee, 'employee_list.html', 'employees')

def employee_add(request):
    return add_item(request, Employee, ['name','position','phone','email','salary'], 'employee_add.html', 'employee_list')

def employee_edit(request, sl):
    return edit_item(request, Employee, sl, ['name','position','phone','email','salary','password'], 'employee_edit.html', 'employee_list')

def employee_delete(request, sl):
    return delete_item(request, Employee, sl, 'employee_list')

# --------------------------
# Supplier CRUD
# --------------------------
def supplier_list(request):
    return list_items(request, Supplier, 'employee_list.html', 'suppliers')

def supplier_add(request):
    return add_item(request, Supplier, ['name','email','phone','raw_material_name'], 'supplier_add.html', 'supplier_list')

def supplier_edit(request, sl):
    return edit_item(request, Supplier, sl, ['name','email','phone','raw_material_name','address'], 'supplier_edit.html', 'supplier_list')

def supplier_delete(request, sl):
    return delete_item(request, Supplier, sl, 'supplier_list')

# --------------------------
# Product CRUD
# --------------------------
def product_list(request):
    return list_items(request, Product, 'product_list.html', 'products')

def product_add(request):
    return add_item(request, Product, ['name','price'], 'product_add.html', 'product_list')

def product_edit(request, sl):
    return edit_item(request, Product, sl, ['name','price'], 'product_edit.html', 'product_list')

def product_delete(request, sl):
    return delete_item(request, Product, sl, 'product_list')

# --------------------------
# Authentication & Signup
# --------------------------
def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def employee_register_page(request):
    return render(request, "employee-register.html")

def supplier_register_page(request):
    return render(request, "supplier-register.html")

def login_page(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        try:
            emp = Employee.objects.get(email=email, password=password)
            user, created = User.objects.get_or_create(
                username=email,
                defaults={'email': email}
            )
            auth_login(request, user)
            request.session['employee_id'] = emp.sl
            profile = get_object_or_404(EmployeeProfile, user__email=email)
            return redirect('dashboard')
        except Employee.DoesNotExist:
            pass

        supplier = Supplier.objects.filter(email=email, password=password).first()
        if supplier:
            request.session['supplier_id'] = supplier.sl
            return redirect('supplier_dashboard')

        messages.error(request, "Invalid email or password")

    return render(request, "login.html")

# --------------------------
# Supplier login page
# --------------------------
def supplier_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        supplier = Supplier.objects.filter(email=email, password=password).first()
        if supplier:
            request.session['supplier_id'] = supplier.sl
            return redirect('supplier_dashboard')
        else:
            messages.error(request, "Invalid email or password")

    return render(request, 'supplier_login.html')

@csrf_exempt
def employee_register(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        password = request.POST.get("password")
        phone = request.POST.get("phone")  

        user = User.objects.create_user(username=email, email=email, password=password)
        emp= Employee.objects.create(
            name=name,
            email=email,
            password=password,
            phone=phone
        )
        EmployeeProfile.objects.create(
            user=user,
            phone=phone,
            designation="Worker",
            employee=emp   
        )
        return redirect('login_page')   
    return redirect('employee_register_page')   

@csrf_exempt
def supplier_register(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        password = request.POST.get("password")
        phone = request.POST.get("phone")   
        address = request.POST.get("address")   

        Supplier.objects.create(
            name=name,
            email=email,
            password=password,
            phone=phone,
            address=address
        )
        return redirect('login_page')  
    return redirect('supplier_register_page')  

# --------------------------
# Admin
# --------------------------
def custom_admin_login(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            if user.is_staff:  
                login(request, user)
                return redirect('employee_list')  
            else:
                return redirect('login') 
    else:
        form = AuthenticationForm()

    return render(request, 'admin_login.html', {'form': form})

@login_required(login_url='admin_login')
def admin_redirect(request):
    if request.user.is_authenticated and request.user.is_staff:
        from datetime import datetime
        from .models import PaymentTransaction
        
        employees = Employee.objects.annotate(total_production=Sum('production__quantity'))
        suppliers = Supplier.objects.all()
        
        # Get current month and year
        current_date = timezone.now()
        month_start = current_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        month_end = (month_start + timezone.timedelta(days=32)).replace(day=1)
        
        # Find employees who HAVE been paid this month
        paid_employee_ids = PaymentTransaction.objects.filter(
            employee__isnull=False,
            status='success',
            created_at__gte=month_start,
            created_at__lt=month_end
        ).values_list('employee_id', flat=True).distinct()
        
        # Find suppliers who HAVE been paid this month
        paid_supplier_ids = PaymentTransaction.objects.filter(
            supplier__isnull=False,
            status='success',
            created_at__gte=month_start,
            created_at__lt=month_end
        ).values_list('supplier_id', flat=True).distinct()
        
        # Attach payment_status to each employee
        for emp in employees:
            emp.payment_status = 'Paid' if emp.sl in paid_employee_ids else 'Unpaid'
        
        # Attach payment_status to each supplier
        for sup in suppliers:
            sup.payment_status = 'Paid' if sup.sl in paid_supplier_ids else 'Unpaid'
        
        return render(request, 'employee_list.html', {
            'employees': employees,
            'suppliers': suppliers,
            'products': Product.objects.all(),
        })
    return redirect('admin_login')

def admin_logout(request):
    logout(request)  
    return redirect('admin_login')  

@login_required(login_url='admin_login')
def take_attendance(request):
    if request.user.is_authenticated and request.user.is_staff: 
        employees = EmployeeProfile.objects.all()
        if request.method == 'POST':
            today = timezone.now().date()
            for emp in employees:
                present = request.POST.get(f'attend_{emp.id}') == 'on'
                Attendance.objects.create(
                    employee=emp,
                    date=today,
                    status='IN' if present else 'OUT',
                    marked_by_admin=True
                )
            return redirect('attendance_list')
    return render(request, 'take_attendance.html', {'employees': employees})

@login_required(login_url='admin_login')
def attendance_list(request):
    if request.user.is_authenticated and request.user.is_staff: 
        attendances = Attendance.objects.select_related('employee').order_by('-timestamp')
        return render(request, 'attendance_list.html', {'attendances': attendances})

@login_required(login_url='admin_login')
def attendance_edit(request, pk):
    if request.user.is_authenticated and request.user.is_staff: 
        attendance = get_object_or_404(Attendance, pk=pk)

        if request.method == 'POST':
            form = AttendanceEditForm(request.POST, instance=attendance)
            if form.is_valid():
                form.save()
                return redirect('attendance_list')
        else:
            form = AttendanceEditForm(instance=attendance)

    return render(request, 'attendance_edit.html', {'form': form, 'attendance': attendance})

@login_required(login_url='admin_login')
def employee_bonus(request):
    if request.user.is_authenticated and request.user.is_staff: 
        employees = Employee.objects.all()
        if request.method == "POST":
            emp_id = request.POST.get("employee")
            bonus = request.POST.get("bonus")
            try:
                emp = Employee.objects.get(sl=emp_id)
                emp.salary = emp.salary + (emp.salary * int(bonus) / 100)
                emp.save()
            except Employee.DoesNotExist:
                pass
            return redirect('employee_list')  

    return render(request, 'employee_bonus.html', {"employees": employees})

# --------------------------
# Employee production
# --------------------------
def employee_dashboard(request):
    emp_id = request.session.get('employee_id')
    if not emp_id:
        return redirect('login_page')
    
    employee = Employee.objects.get(sl=emp_id)

    if request.method == 'POST':
        form = ProductionForm(request.POST)
        if form.is_valid():
            production = form.save(commit=False)
            production.employee = employee
            production.save()
            return redirect('employee_dashboard')  

    form = ProductionForm()
    productions = Production.objects.filter(employee=employee).order_by('-date')
    total_production = productions.aggregate(total=Sum('quantity'))['total'] or 0

    print(f"Productions for {employee.name}: {productions}")  

    return render(request, 'employee.html', {
        'form': form,
        'productions': productions,
        'total_production': total_production
    })

# --------------------------
# Employee dashboard
# --------------------------
def home(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return redirect('index')

def dashboard_view(request):
        return render(request, 'dashboard.html') 

def logout_view(request):
    logout(request)   
    return redirect('login_page') 

@login_required
def dashboard(request):
    profile, _ = EmployeeProfile.objects.get_or_create(user=request.user)
    today = date.today()
    
    dailywork, _ = DailyWork.objects.get_or_create(employee=profile, date=today)

    if request.method == 'POST':
        if 'product_submit' in request.POST:
            pform = ProductCountForm(request.POST, instance=dailywork)
            if pform.is_valid():
                pform.instance.employee = profile
                pform.instance.date = today
                pform.save()

                production, created = Production.objects.get_or_create(
                    employee_profile=profile, 
                    date=today,
                    defaults={'employee': profile.employee,'quantity': dailywork.product_count}
                )
                if not created:
                    production.quantity = dailywork.product_count
                    production.save()

                messages.success(request, 'Daily product count and production history updated.')
                return redirect('dashboard')

        elif 'clock_in' in request.POST or 'clock_out' in request.POST:
            status = 'IN' if 'clock_in' in request.POST else 'OUT'
            Attendance.objects.create(employee=profile, status=status, marked_by_admin=False)
            messages.success(request, f'Attendance { "clocked in" if status=="IN" else "clocked out" }.')
            return redirect('dashboard')
    else:
        pform = ProductCountForm(instance=dailywork)

    productions = Production.objects.filter(employee_profile=profile).order_by('-date')
    total_production = productions.aggregate(total=Sum('quantity'))['total'] or 0

    last_attendances = profile.attendances.order_by('-timestamp')[:8]

    context = {
        'profile': profile,
        'pform': pform,
        'product_count': dailywork.product_count,
        'last_attendances': last_attendances,
        'today': today,
        'productions': productions,
        'total_production': total_production,
    }
    return render(request, 'dashboard.html', context)

@login_required
def profile_view(request):
    profile, _ = EmployeeProfile.objects.get_or_create(user=request.user)
    return render(request, 'profile.html', {'profile': profile})

@login_required
def attendance_history(request):
    profile = get_object_or_404(EmployeeProfile, user=request.user)
    attendances = profile.attendances.order_by('-timestamp')
    return render(request, 'attendance_history.html', {'attendances': attendances})

# --------------------------
# Supplier dashboard
# --------------------------
def supplier_dashboard(request):
    sup_id = request.session.get('supplier_id')
    if not sup_id:
        return redirect('supplier_login')

    supplier = get_object_or_404(Supplier, sl=sup_id)

    if request.method == 'POST':
        raw_material = request.POST.get('Raw_Material')
        quantity_raw = request.POST.get('Quantity')
        price_raw = request.POST.get('Price')

        # Convert to correct data types with fallback to existing values
        try:
            quantity = int(quantity_raw)
        except (ValueError, TypeError):
            quantity = supplier.Quantity

        try:
            price = int(price_raw)
        except (ValueError, TypeError):
            price = supplier.Price

        # Track if updated
        updated = False

        # Check Raw_Material update
        if raw_material and supplier.Raw_Material != raw_material:
            supplier.Raw_Material = raw_material
            updated = True

        # Check Quantity update
        if supplier.Quantity != quantity:
            supplier.Quantity = quantity
            updated = True

        # Check Price update
        if supplier.Price != price:
            supplier.Price = price
            updated = True

        if updated:
            supplier.save()
            messages.success(request, "Supplier details updated successfully.")
        else:
            messages.info(request, "No changes detected.")

        # Use Post/Redirect/Get to avoid form resubmission when user refreshes
        return redirect('supplier_dashboard')

    context = {
        'supplier': supplier,
    }
    return render(request, 'supplier_dashboard.html', context)



def supplier_logout(request):
    request.session.flush()
    return redirect('index')

# --------------------------
# Admin Dashboard PDF Download
# --------------------------
@login_required(login_url='admin_login')
def download_admin_dashboard_pdf(request):
    """Generate and download admin dashboard as PDF"""
    if request.user.is_authenticated and request.user.is_staff:
        # Prepare dashboard data and rendered HTML (always available as a fallback)
        employees = Employee.objects.annotate(total_production=Sum('production__quantity'))
        suppliers = Supplier.objects.all()
        products = Product.objects.all()

        # Determine payment status for current month
        current_date = timezone.now()
        month_start = current_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        month_end = (month_start + timezone.timedelta(days=32)).replace(day=1)

        paid_employee_ids = PaymentTransaction.objects.filter(
            employee__isnull=False,
            status='success',
            created_at__gte=month_start,
            created_at__lt=month_end
        ).values_list('employee_id', flat=True).distinct()

        paid_supplier_ids = PaymentTransaction.objects.filter(
            supplier__isnull=False,
            status='success',
            created_at__gte=month_start,
            created_at__lt=month_end
        ).values_list('supplier_id', flat=True).distinct()

        # Attach payment_status attribute for template rendering
        for emp in employees:
            emp.payment_status = 'Paid' if emp.sl in paid_employee_ids else 'Unpaid'

        for sup in suppliers:
            sup.payment_status = 'Paid' if sup.sl in paid_supplier_ids else 'Unpaid'

        # Render HTML template (available even if PDF generation fails)
        html_content = render_to_string('admin_dashboard_pdf.html', {
            'employees': employees,
            'suppliers': suppliers,
            'products': products,
            'generated_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        })

        # Now attempt PDF generation if the library is available
        try:
            # Import xhtml2pdf locally to ensure it's available
            from xhtml2pdf import pisa as pisa_module

            # Generate PDF using xhtml2pdf (pass bytes when possible)
            pdf_buffer = BytesIO()
            try:
                # Try passing encoded bytes (more reliable for encodings)
                pisa_status = pisa_module.CreatePDF(
                    html_content.encode('utf-8'),
                    dest=pdf_buffer,
                    encoding='UTF-8'
                )
            except TypeError:
                # Fallback: some environments expect a string source
                pisa_status = pisa_module.CreatePDF(
                    html_content,
                    dest=pdf_buffer,
                    encoding='UTF-8'
                )

            if pisa_status.err:
                # If PDF generation failed, fall back to returning the rendered HTML
                fallback_name = 'admin_dashboard_{}.html'.format(datetime.now().strftime('%Y%m%d_%H%M%S'))
                response = HttpResponse(html_content, content_type='text/html; charset=utf-8')
                response['Content-Disposition'] = 'attachment; filename="{}"'.format(fallback_name)
                return response

            pdf_buffer.seek(0)

            # Create HTTP response
            response = HttpResponse(pdf_buffer.getvalue(), content_type='application/pdf')
            response['Content-Disposition'] = 'attachment; filename="admin_dashboard_{}.pdf"'.format(
                datetime.now().strftime('%Y%m%d_%H%M%S')
            )

            return response
        
        except ModuleNotFoundError as e:
            error_msg = "PDF generation library (xhtml2pdf) not installed: " + str(e)
            import traceback
            tb = traceback.format_exc()
            # log to file for easier debugging
            with open('pdf_errors.log', 'a', encoding='utf-8') as _f:
                _f.write('\n==== ModuleNotFoundError at {} ====' .format(datetime.now().isoformat()))
                _f.write('\n' + error_msg + '\n')
                _f.write(tb + '\n')
            # Return the rendered HTML as fallback attachment so the admin can still download the content
            fallback_name = 'admin_dashboard_{}.html'.format(datetime.now().strftime('%Y%m%d_%H%M%S'))
            response = HttpResponse(html_content, content_type='text/html; charset=utf-8')
            response['Content-Disposition'] = 'attachment; filename="{}"'.format(fallback_name)
            return response

        except Exception as e:
            error_msg = "PDF generation error: " + str(e)
            import traceback
            tb = traceback.format_exc()
            # log the full traceback to a file for inspection
            with open('pdf_errors.log', 'a', encoding='utf-8') as _f:
                _f.write('\n==== PDF generation Exception at {} ====' .format(datetime.now().isoformat()))
                _f.write('\n' + error_msg + '\n')
                _f.write(tb + '\n')
            # Return a concise message to the browser
            return HttpResponse('PDF generation failed. See pdf_errors.log for details.', status=500)
    
    return redirect('admin_login')

# --------------------------
# Employee Rating
# --------------------------
@login_required(login_url='admin_login')
def update_employee_rating(request, employee_id):
    """Update employee rating via AJAX"""
    if not (request.user.is_authenticated and request.user.is_staff):
        return HttpResponse('Unauthorized', status=401)
    
    if request.method == 'POST':
        import json
        try:
            data = json.loads(request.body)
            rating = data.get('rating')
            
            # Validate rating
            valid_ratings = ['Excellent', 'Good', 'Average', 'Poor']
            if rating not in valid_ratings:
                return HttpResponse(json.dumps({'error': 'Invalid rating'}), 
                                  content_type='application/json', status=400)
            
            # Update employee
            employee = get_object_or_404(Employee, sl=employee_id)
            employee.rating = rating
            employee.save()
            
            return HttpResponse(json.dumps({'success': True, 'rating': rating}), 
                              content_type='application/json')
        except Exception as e:
            return HttpResponse(json.dumps({'error': str(e)}), 
                              content_type='application/json', status=500)
    
    return HttpResponse('Method not allowed', status=405)


# --------------------------
# Payment integration (SSLCommerz) - generic flow for employee/supplier
# --------------------------
@login_required(login_url='admin_login')
def initiate_payment(request):
    # Check if user is staff (admin)
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'User not authenticated'}, status=401)
    
    if not request.user.is_staff:
        return JsonResponse({'error': 'Insufficient permissions'}, status=403)

    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)

    target_type = request.POST.get('target_type', '').strip()
    target_id = request.POST.get('target_id', '').strip()
    amount = request.POST.get('amount', '').strip()

    # Validate inputs
    if not target_type:
        return JsonResponse({'error': 'Missing target_type parameter'}, status=400)
    if not target_id:
        return JsonResponse({'error': 'Missing target_id parameter'}, status=400)
    if not amount:
        return JsonResponse({'error': 'Missing amount parameter'}, status=400)

    employee = None
    supplier = None

    try:
        target_id = int(target_id)  # Convert to int for database lookup
        
        if target_type == 'employee':
            employee = get_object_or_404(Employee, sl=target_id)
            default_amount = employee.salary
        elif target_type == 'supplier':
            supplier = get_object_or_404(Supplier, sl=target_id)
            default_amount = getattr(supplier, 'Price', 0)
        else:
            return JsonResponse({'error': f'Invalid target_type: {target_type}'}, status=400)
    except ValueError:
        return JsonResponse({'error': 'target_id must be a valid integer'}, status=400)
    except Http404:
        return JsonResponse({'error': f'{target_type.capitalize()} with id {target_id} not found'}, status=404)
    except Exception as e:
        return JsonResponse({'error': f'Error finding target: {str(e)}'}, status=500)

    try:
        amount_val = float(amount)
        if amount_val <= 0:
            return JsonResponse({'error': 'Amount must be greater than 0'}, status=400)
    except ValueError:
        return JsonResponse({'error': f'Invalid amount value: {amount}'}, status=400)

    # Create order id
    order_id = f"PAY-{target_type[:3].upper()}-{uuid.uuid4().hex[:10]}"

    # Create PaymentTransaction record
    from .models import PaymentTransaction
    try:
        txn = PaymentTransaction.objects.create(
            order_id=order_id,
            employee=employee,
            supplier=supplier,
            amount=amount_val,
            currency='BDT',
            status='pending'
        )
    except Exception as e:
        return JsonResponse({'error': f'Failed to create transaction: {str(e)}'}, status=500)

    # Check settings
    store_id = getattr(settings, 'SSL_COMMERZ_STORE_ID', None)
    store_pass = getattr(settings, 'SSL_COMMERZ_STORE_PASSWORD', None)
    if not store_id or not store_pass:
        txn.status = 'failed'
        txn.metadata = {'error': 'missing_store_credentials'}
        txn.save()
        return JsonResponse({'error': 'Payment credentials not configured. Please contact administrator.'}, status=500)

    # Prepare payload for SSLCommerz (sandbox endpoint)
    try:
        success_url = request.build_absolute_uri(reverse('ssl_success'))
        fail_url = request.build_absolute_uri(reverse('ssl_fail'))
        cancel_url = request.build_absolute_uri(reverse('ssl_fail'))
    except Exception as e:
        return JsonResponse({'error': f'Failed to build URLs: {str(e)}'}, status=500)

    payload = {
        'store_id': store_id,
        'store_passwd': store_pass,
        'total_amount': str(amount_val),
        'currency': 'BDT',
        'tran_id': order_id,
        'success_url': success_url,
        'fail_url': fail_url,
        'cancel_url': cancel_url,
        'cus_name': employee.name if employee else (supplier.name if supplier else 'Customer'),
        'cus_email': employee.email if employee else (supplier.email if supplier else 'customer@example.com'),
        'cus_phone': str(employee.phone) if employee else (str(supplier.phone) if supplier else '0000000000'),
        'cus_add1': 'N/A',
        'cus_city': 'Dhaka',
        'cus_postcode': '1000',
        'cus_country': 'Bangladesh',
        'ship_name': employee.name if employee else (supplier.name if supplier else 'Customer'),
        'ship_add1': 'N/A',
        'ship_city': 'Dhaka',
        'ship_postcode': '1000',
        'ship_country': 'Bangladesh',
        'shipping_method': 'NO',
        'product_name': f'Salary Payment - {order_id}',
        'product_category': 'topup',  # Required field - using 'topup' for salary/payment transactions
        'product_profile': 'general',
        'value_a': str(txn.id),
    }

    try:
        api_url = getattr(settings, 'SSLCOMMERZ_API_URL', 'https://sandbox.sslcommerz.com/gwprocess/v4/api.php')
        resp = requests.post(api_url, data=payload, timeout=15)
        resp.raise_for_status()  # Raise exception for non-200 status codes
        
        try:
            data = resp.json()
        except ValueError as e:
            import sys
            print(f"JSON Parse Error: {str(e)}", file=sys.stderr)
            print(f"Response text: {resp.text}", file=sys.stderr)
            return JsonResponse({'error': 'Invalid JSON response from payment gateway'}, status=500)

        # Log the gateway response for debugging
        import sys
        print(f"Gateway response: {data}", file=sys.stderr)

        # Expected: status 'SUCCESS' and 'GatewayPageURL'
        if data.get('status') in ('SUCCESS', 'success') and data.get('GatewayPageURL'):
            gateway_url = data['GatewayPageURL']
            return JsonResponse({'gateway_url': gateway_url, 'success': True})
        else:
            txn.status = 'failed'
            txn.metadata = data
            txn.save()
            error_msg = data.get('failedreason', data.get('status', 'Unknown error'))
            print(f"Gateway error: {error_msg}", file=sys.stderr)
            return JsonResponse({'error': f'Payment gateway error: {error_msg}'}, status=400)
    
    except requests.exceptions.Timeout:
        txn.status = 'failed'
        txn.metadata = {'error': 'Gateway timeout after 15 seconds'}
        txn.save()
        return JsonResponse({'error': 'Payment gateway timed out. Please try again.'}, status=500)
    
    except requests.exceptions.ConnectionError as e:
        txn.status = 'failed'
        txn.metadata = {'error': f'Connection failed: {str(e)}'}
        txn.save()
        return JsonResponse({'error': 'Failed to connect to payment gateway. Check your internet connection.'}, status=500)
    
    except requests.exceptions.RequestException as e:
        txn.status = 'failed'
        txn.metadata = {'error': str(e)}
        txn.save()
        return JsonResponse({'error': f'Gateway communication error: {str(e)}'}, status=500)
    
    except Exception as e:
        txn.status = 'failed'
        txn.metadata = {'error': str(e)}
        txn.save()
        return JsonResponse({'error': f'Payment processing error: {str(e)}'}, status=500)


@csrf_exempt
def ssl_success(request):
    # Called after payment success (user redirect)
    tran_id = request.GET.get('tran_id') or request.POST.get('tran_id')
    val_id = request.GET.get('val_id') or request.POST.get('val_id')
    status = request.GET.get('status') or request.POST.get('status')

    from .models import PaymentTransaction
    try:
        txn = PaymentTransaction.objects.get(order_id=tran_id)
    except PaymentTransaction.DoesNotExist:
        return HttpResponse('Unknown transaction', status=404)

    if txn.status != 'success':
        txn.status = 'success'
        txn.ssl_txn_id = val_id or txn.ssl_txn_id
        txn.metadata = txn.metadata or {}
        txn.metadata.update({'status': status})
        txn.save()

        # send confirmation email if possible
        try:
            recipient = txn.employee.email if txn.employee else (txn.supplier.email if txn.supplier else None)
            if recipient:
                send_mail(
                    subject='Payment Received',
                    message=f'Payment of {txn.amount} {txn.currency} has been received for order {txn.order_id}.',
                    from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', None),
                    recipient_list=[recipient],
                    fail_silently=True,
                )
        except Exception:
            pass

    messages.success(request, f'Payment processed for {txn.order_id}.')
    return redirect('employee_list')


@csrf_exempt
def ssl_fail(request):
    tran_id = request.GET.get('tran_id') or request.POST.get('tran_id')
    from .models import PaymentTransaction
    try:
        txn = PaymentTransaction.objects.get(order_id=tran_id)
        txn.status = 'failed'
        txn.save()
    except PaymentTransaction.DoesNotExist:
        pass
    messages.error(request, 'Payment failed or cancelled.')
    return redirect('employee_list')


@csrf_exempt
def ssl_ipn(request):
    # IPN handler - SSLCommerz server-to-server notification
    from .models import PaymentTransaction
    try:
        post = request.POST
        tran_id = post.get('tran_id')
        val_id = post.get('val_id')
        status = post.get('status')

        if not tran_id:
            return HttpResponse('Missing tran_id', status=400)

        txn = PaymentTransaction.objects.filter(order_id=tran_id).first()
        if not txn:
            return HttpResponse('Unknown transaction', status=404)

        if status and status.upper() in ('VALID', 'SUCCESS'):
            if txn.status != 'success':
                txn.status = 'success'
                txn.ssl_txn_id = val_id or txn.ssl_txn_id
                txn.metadata = txn.metadata or {}
                txn.metadata.update({'ipn': dict(post)})
                txn.save()
                # notify recipient
                try:
                    recipient = txn.employee.email if txn.employee else (txn.supplier.email if txn.supplier else None)
                    if recipient:
                        send_mail(
                            subject='Payment Confirmed',
                            message=f'Your payment of {txn.amount} {txn.currency} for order {txn.order_id} is confirmed.',
                            from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', None),
                            recipient_list=[recipient],
                            fail_silently=True,
                        )
                except Exception:
                    pass
        else:
            txn.status = 'failed'
            txn.metadata = txn.metadata or {}
            txn.metadata.update({'ipn': dict(post)})
            txn.save()

        return HttpResponse('OK')
    except Exception as e:
        return HttpResponse('Error: ' + str(e), status=500)


@login_required(login_url='admin_login')
def payment_transactions_list(request):
    """Admin view: list payment transactions with actions"""
    if not (request.user.is_authenticated and request.user.is_staff):
        return redirect('admin_login')

    from .models import PaymentTransaction
    txns = PaymentTransaction.objects.select_related('employee', 'supplier').order_by('-created_at')
    return render(request, 'payment_transactions_list.html', {'transactions': txns})


@login_required(login_url='admin_login')
def retry_payment_transaction(request, pk):
    """Admin: retry a failed/cancelled transaction by creating a new transaction and initiating gateway."""
    if not (request.user.is_authenticated and request.user.is_staff):
        return HttpResponse('Unauthorized', status=401)

    from .models import PaymentTransaction
    orig = get_object_or_404(PaymentTransaction, pk=pk)

    # Only allow retry for non-success transactions
    if orig.status == 'success':
        messages.info(request, 'Transaction already successful; cannot retry.')
        return redirect('payment_transactions_list')

    # create a new transaction and attempt initiation (similar to initiate_payment)
    order_id = f"RETRY-{uuid.uuid4().hex[:10]}"
    txn = PaymentTransaction.objects.create(
        order_id=order_id,
        employee=orig.employee,
        supplier=orig.supplier,
        amount=orig.amount,
        currency=orig.currency,
        status='pending'
    )

    store_id = getattr(settings, 'SSL_COMMERZ_STORE_ID', None)
    store_pass = getattr(settings, 'SSL_COMMERZ_STORE_PASSWORD', None)
    if not store_id or not store_pass:
        txn.status = 'failed'
        txn.metadata = {'error': 'missing_store_credentials'}
        txn.save()
        messages.error(request, 'Payment credentials not configured.')
        return redirect('payment_transactions_list')

    success_url = request.build_absolute_uri(reverse('ssl_success'))
    fail_url = request.build_absolute_uri(reverse('ssl_fail'))

    payload = {
        'store_id': store_id,
        'store_passwd': store_pass,
        'total_amount': str(txn.amount),
        'currency': txn.currency,
        'tran_id': txn.order_id,
        'success_url': success_url,
        'fail_url': fail_url,
        'cancel_url': fail_url,
        'cus_name': txn.employee.name if txn.employee else (txn.supplier.name if txn.supplier else ''),
        'cus_email': txn.employee.email if txn.employee else (txn.supplier.email if txn.supplier else ''),
        'cus_phone': txn.employee.phone if txn.employee else (txn.supplier.phone if txn.supplier else ''),
        'value_a': str(txn.id),
    }

    try:
        api_url = getattr(settings, 'SSLCOMMERZ_API_URL', 'https://sandbox.sslcommerz.com/gwprocess/v4/api.php')
        resp = requests.post(api_url, data=payload, timeout=15)
        data = resp.json()
        if data.get('status') in ('SUCCESS', 'success') and data.get('GatewayPageURL'):
            gateway_url = data['GatewayPageURL']
            return redirect(gateway_url)
        else:
            txn.status = 'failed'
            txn.metadata = data
            txn.save()
            messages.error(request, 'Retry initiation failed.')
            return redirect('payment_transactions_list')
    except Exception as e:
        txn.status = 'failed'
        txn.metadata = {'exception': str(e)}
        txn.save()
        messages.error(request, 'Retry error: ' + str(e))
        return redirect('payment_transactions_list')


@login_required(login_url='admin_login')
def refund_payment_transaction(request, pk):
    """Admin: mark a transaction as refunded (placeholder for gateway refund API)."""
    if not (request.user.is_authenticated and request.user.is_staff):
        return HttpResponse('Unauthorized', status=401)

    from .models import PaymentTransaction
    txn = get_object_or_404(PaymentTransaction, pk=pk)

    # If already refunded or not successful, still allow marking refunded
    try:
        # Placeholder: if a refund API is available, call it here using settings
        # For now, mark locally as refunded and record metadata
        txn.status = 'refunded'
        meta = txn.metadata or {}
        meta.update({'refunded_by': request.user.username, 'refunded_at': str(timezone.now())})
        txn.metadata = meta
        txn.save()
        messages.success(request, f'Transaction {txn.order_id} marked as refunded.')
    except Exception as e:
        messages.error(request, 'Refund failed: ' + str(e))

    return redirect('payment_transactions_list')


@login_required(login_url='admin_login')
def mark_payment_as_paid(request):
    """Admin: mark an employee/supplier payment as paid without gateway (manual/off-platform payment)."""
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'User not authenticated'}, status=401)
    
    if not request.user.is_staff:
        return JsonResponse({'error': 'Insufficient permissions'}, status=403)

    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)

    target_type = request.POST.get('target_type', '').strip()
    target_id = request.POST.get('target_id', '').strip()
    amount = request.POST.get('amount', '').strip()

    if not target_type or not target_id or not amount:
        return JsonResponse({'error': 'Missing required parameters'}, status=400)

    employee = None
    supplier = None

    try:
        target_id = int(target_id)
        
        if target_type == 'employee':
            employee = get_object_or_404(Employee, sl=target_id)
        elif target_type == 'supplier':
            supplier = get_object_or_404(Supplier, sl=target_id)
        else:
            return JsonResponse({'error': f'Invalid target_type: {target_type}'}, status=400)
    except ValueError:
        return JsonResponse({'error': 'target_id must be a valid integer'}, status=400)
    except Http404:
        return JsonResponse({'error': f'{target_type.capitalize()} with id {target_id} not found'}, status=404)
    except Exception as e:
        return JsonResponse({'error': f'Error finding target: {str(e)}'}, status=500)

    try:
        amount_val = float(amount)
        if amount_val <= 0:
            return JsonResponse({'error': 'Amount must be greater than 0'}, status=400)
    except ValueError:
        return JsonResponse({'error': f'Invalid amount value: {amount}'}, status=400)

    # Create order id
    order_id = f"MANUAL-{target_type[:3].upper()}-{uuid.uuid4().hex[:10]}"

    # Create PaymentTransaction record marked as success
    from .models import PaymentTransaction
    try:
        txn = PaymentTransaction.objects.create(
            order_id=order_id,
            employee=employee,
            supplier=supplier,
            amount=amount_val,
            currency='BDT',
            status='success',
            metadata={'marked_paid_by': request.user.username, 'marked_at': str(timezone.now()), 'payment_type': 'manual'}
        )
    except Exception as e:
        return JsonResponse({'error': f'Failed to create payment record: {str(e)}'}, status=500)

    # Send confirmation email
    try:
        recipient = employee.email if employee else (supplier.email if supplier else None)
        if recipient:
            send_mail(
                subject='Payment Marked as Paid',
                message=f'Payment of {amount_val} BDT has been marked as paid for order {order_id}.',
                from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', None),
                recipient_list=[recipient],
                fail_silently=True,
            )
    except Exception as e:
        import sys
        print(f"Email sending error (non-blocking): {str(e)}", file=sys.stderr)

    return JsonResponse({'success': True, 'message': 'Payment marked as paid successfully', 'order_id': order_id})
