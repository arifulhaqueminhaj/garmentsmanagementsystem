from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('admin/', views.custom_admin_login, name='admin_login'),
    path('', views.index, name='index'),
    path('admin/login/', views.custom_admin_login, name='admin_login'),
    path('admin/employee-list/', views.admin_redirect, name='employee_list'),
    path('admin-redirect/', views.admin_redirect, name='admin_redirect'),
    path('admin/logout/', views.admin_logout, name='admin_logout'),
    
    path('about/', views.about, name='about'),
    path('login/', views.login_page, name='login_page'),
    path('employee-register/', views.employee_register_page, name='employee_register_page'),
    path('supplier-register/', views.supplier_register_page, name='supplier_register_page'),
    
    path('employee/register/', views.employee_register, name='employee_register'),
    path('supplier/register/', views.supplier_register, name='supplier_register'),

    path('employees/add/', views.employee_add, name='employee_add'),
    path('employees/edit/<int:sl>/', views.employee_edit, name='employee_edit'),
    path('employees/delete/<int:sl>/', views.employee_delete, name='employee_delete'),

    path('supplier/add/', views.supplier_add, name='supplier_add'),
    path('supplier/edit/<int:sl>/', views.supplier_edit, name='supplier_edit'),
    path('supplier/delete/<int:sl>/', views.supplier_delete, name='supplier_delete'),

    path('supplier/dashboard/', views.supplier_dashboard, name='supplier_dashboard'),
    path('supplier/logout/', views.supplier_logout, name='supplier_logout'),

    path('products/', views.product_list, name='product_list'),
    path('products/add/', views.product_add, name='product_add'),
    path('products/edit/<int:sl>/', views.product_edit, name='product_edit'),
    path('products/delete/<int:sl>/', views.product_delete, name='product_delete'),
    
    path('attendance/', views.take_attendance, name='take_attendance'),
    path('attendance/all/', views.attendance_list, name='attendance_list'),
    path('attendance/edit/<int:pk>/', views.attendance_edit, name='attendance_edit'),
    
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('profile/', views.profile_view, name='profile'),
    path('attendanceE/', views.attendance_history, name='attendance_history'),

    path('employee/bonus/', views.employee_bonus, name='employee_bonus'),
    
    path('admin/dashboard/download-pdf/', views.download_admin_dashboard_pdf, name='download_admin_pdf'),
    path('employee/rate/<int:employee_id>/', views.update_employee_rating, name='update_employee_rating'),
    # Admin payment transaction management
    path('admin/payments/transactions/', views.payment_transactions_list, name='payment_transactions_list'),
    path('admin/payments/retry/<int:pk>/', views.retry_payment_transaction, name='retry_payment_transaction'),
    path('admin/payments/refund/<int:pk>/', views.refund_payment_transaction, name='refund_payment_transaction'),
    # Payment routes
    path('payments/initiate/', views.initiate_payment, name='initiate_payment'),
    path('payments/mark-paid/', views.mark_payment_as_paid, name='mark_payment_as_paid'),
    path('payments/ssl/success/', views.ssl_success, name='ssl_success'),
    path('payments/ssl/fail/', views.ssl_fail, name='ssl_fail'),
    path('payments/ssl/ipn/', views.ssl_ipn, name='ssl_ipn'),
]
    

