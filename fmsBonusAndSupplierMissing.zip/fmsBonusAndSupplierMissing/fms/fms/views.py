from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.views.decorators.csrf import csrf_exempt  ####
from django.http import HttpResponse
from django.contrib.auth.models import User
from fms.models import Employee, Supplier, Product, Attendance
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from .models import Production
from .forms import ProductionForm, BonusForm                                        
from fms import models #######?
from django.db.models import Sum 
from django.contrib.auth.forms import AuthenticationForm
from .models import EmployeeProfile, DailyWork
from .forms import ProductCountForm, AttendanceEditForm
from django.contrib.auth import login as auth_login, logout as auth_logout, authenticate
from django.contrib import messages
from django.views.decorators.http import require_POST
from datetime import date
 


# --------------------------
# Generic CRUD helper
# --------------------------
@login_required(login_url='admin_login')
def list_items(request, model, template, context_name):
    items = model.objects.all()
    return render(request, template, {context_name: items})

@login_required(login_url='admin_login')
def add_item(request, model, fields, template, redirect_url):
    if request.method == "POST":
        data = {field: request.POST[field] for field in fields}
        model.objects.create(**data)
        return redirect('admin_redirect')  # ✅ redirect here
    return render(request, template)

@login_required(login_url='admin_login')
def edit_item(request, model, sl, fields, template, redirect_url):
    item = get_object_or_404(model, sl=sl)
    if request.method == "POST":
        for field in fields:
            setattr(item, field, request.POST[field])
        item.save()
        return redirect('admin_redirect')  # ✅ redirect here
    return render(request, template, {model.__name__.lower(): item})

@login_required(login_url='admin_login')
def delete_item(request, model, sl, redirect_url):
    item = get_object_or_404(model, sl=sl)
    item.delete()
    return redirect('admin_redirect')  # ✅ redirect here


# --------------------------
# Employee CRUD
# --------------------------
def employee_list(request):
    return list_items(request, Employee, 'employee_list.html', 'employees')

def employee_add(request):
    return add_item(request, Employee, ['name','position','phone','email','salary'], 'employee_add.html', 'employee_list')

def employee_edit(request, sl):
    return edit_item(request, Employee, sl, ['name','position','phone','email','salary'], 'employee_edit.html', 'employee_list')

def employee_delete(request, sl):
    return delete_item(request, Employee, sl, 'employee_list')


# --------------------------
# Supplier CRUD
# --------------------------
def supplier_list(request):
    return list_items(request, Supplier, 'employee_list.html', 'suppliers')

def supplier_add(request):
    return add_item(request, Supplier, ['name','email','phone','raw_material_name'], 'supplier_add.html', 'supplier_list')

def supplier_edit(request, sl):
    return edit_item(request, Supplier, sl, ['name','email','phone','raw_material_name','address'], 'supplier_edit.html', 'supplier_list')

def supplier_delete(request, sl):
    return delete_item(request, Supplier, sl, 'supplier_list')


# --------------------------
# Product CRUD
# --------------------------
def product_list(request):
    return list_items(request, Product, 'product_list.html', 'products')

def product_add(request):
    return add_item(request, Product, ['name','price'], 'product_add.html', 'product_list')

def product_edit(request, sl):
    return edit_item(request, Product, sl, ['name','price'], 'product_edit.html', 'product_list')

def product_delete(request, sl):
    return delete_item(request, Product, sl, 'product_list')


# --------------------------
# Authentication & Signup
# --------------------------


# Home page
def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

# Employee registration page
def employee_register_page(request):
    return render(request, "employee-register.html")

# Supplier registration page
def supplier_register_page(request):
    return render(request, "supplier-register.html")

# Unified login page
def login_page(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        # Check Employee first
        try:
            emp = Employee.objects.get(email=email, password=password)
            user, created = User.objects.get_or_create(
                username=email,
                defaults={'email': email}
            )
            # Log in the user
            auth_login(request, user)   # make sure employee is authenticated
            request.session['employee_id'] = emp.sl
            profile = get_object_or_404(EmployeeProfile, user=user)
            profile = get_object_or_404(EmployeeProfile, user__email=email)
            return redirect('dashboard')
        except Employee.DoesNotExist:
            pass

        # Check Supplier next
        try:
            sup = Supplier.objects.get(email=email, password=password)
            request.session['supplier_id'] = sup.sl
            return render(request, 'supplier.html')
        except Supplier.DoesNotExist:
            return render(request, "login.html", {"error": "Invalid email or password!"})

    return render(request, "login.html")


@csrf_exempt
def employee_register(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        password = request.POST.get("password")
        phone = request.POST.get("phone")  

        user = User.objects.create_user(username=email, email=email, password=password)
        Employee.objects.create(
            name=name,
            email=email,
            password=password,
            phone=phone
        )
        EmployeeProfile.objects.create(
            user=user,
            phone=phone,
            designation="Worker"
        )
        return redirect('login_page')   # ✅ redirect to your login page
    return redirect('employee_register_page')   # fallback

@csrf_exempt
def supplier_register(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        password = request.POST.get("password")
        phone = request.POST.get("phone")   
        address = request.POST.get("address")   

        Supplier.objects.create(
            name=name,
            email=email,
            password=password,
            phone=phone,
            address=address
        )
        return redirect('login_page')   # ✅ redirect to your login page
    return redirect('supplier_register_page')   # fallback


# --------------------------
# Admin
# --------------------------
def custom_admin_login(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            if user.is_staff:  # Check if the user is an admin
                login(request, user)
                return redirect('employee_list')  # Redirect to employee list page
            else:
                return redirect('login')  # Handle non-admin users, if necessary
    else:
        form = AuthenticationForm()

    return render(request, 'admin_login.html', {'form': form})

@login_required(login_url='admin_login')
def admin_redirect(request):
    if request.user.is_authenticated and request.user.is_staff: ########
        return render(request, 'employee_list.html', {
            'employees': Employee.objects.all(),
            'suppliers': Supplier.objects.all(),
            'products': Product.objects.all()
        })
    return redirect('admin_login')

def admin_logout(request):
    logout(request)  # Logs out the user
    return redirect('admin_login')  # Redirect to the login page

@login_required(login_url='admin_login')
def take_attendance(request):
    employees = EmployeeProfile.objects.all()
    if request.method == 'POST':
        today = timezone.now().date()
        for emp in employees:
            present = request.POST.get(f'attend_{emp.id}') == 'on'
            Attendance.objects.create(
                employee=emp,
                date=today,
                status='IN' if present else 'OUT',
                marked_by_admin=True
            )
        messages.success(request, "Attendance recorded for all employees.")
        return redirect('attendance_list')
    return render(request, 'take_attendance.html', {'employees': employees})



@login_required(login_url='admin_login')
def attendance_list(request):
    attendances = Attendance.objects.select_related('employee').order_by('-timestamp')
    return render(request, 'attendance_list.html', {'attendances': attendances})


@login_required(login_url='admin_login')
def attendance_edit(request, pk):
    """
    Admin view to edit a specific attendance record
    """
    attendance = get_object_or_404(Attendance, pk=pk)

    if request.method == 'POST':
        form = AttendanceEditForm(request.POST, instance=attendance)
        if form.is_valid():
            form.save()
            return redirect('attendance_list')
    else:
        form = AttendanceEditForm(instance=attendance)

    return render(request, 'attendance_edit.html', {'form': form, 'attendance': attendance})

@login_required(login_url='admin_login')
def employee_bonus(request, sl):
    # Fetch employee
    employee = get_object_or_404(Employee, sl=sl)

    if request.method == "POST":
        form = BonusForm(request.POST)
        if form.is_valid():
            percentage = form.cleaned_data['percentage']
            # Calculate bonus amount
            bonus_amount = (employee.salary * percentage) / 100
            employee.salary += bonus_amount  # Update salary
            employee.save()
            messages.success(request, f"{employee.name}'s salary updated with {percentage}% bonus.")
            return redirect('employee_list')
    else:
        form = BonusForm()

    return render(request, 'employee_bonus.html', {'form': form, 'employee': employee})

# --------------------------
# production
# --------------------------
def employee_dashboard(request):
    emp_id = request.session.get('employee_id')
    if not emp_id:
        return redirect('login_page')
    
    # Get the logged-in employee object
    employee = Employee.objects.get(sl=emp_id)

    # Handle POST request for adding new production record
    if request.method == 'POST':
        form = ProductionForm(request.POST)
        if form.is_valid():
            production = form.save(commit=False)
            production.employee = employee
            production.save()
            return redirect('employee_dashboard')  # Refresh the page after submission

    # GET request or invalid form, retrieve employee production records
    form = ProductionForm()
    productions = Production.objects.filter(employee=employee).order_by('-date')
    total_production = productions.aggregate(total=Sum('quantity'))['total'] or 0

    print(f"Productions for {employee.name}: {productions}")  # Debugging line

    return render(request, 'employee.html', {
        'form': form,
        'productions': productions,
        'total_production': total_production
    })

# --------------------------
# User dashboard
# --------------------------
def home(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return redirect('index')

def dashboard_view(request):
        return render(request, 'dashboard.html') 

def logout_view(request):
    logout(request)   # clears the session
    return redirect('login_page')  # send back to login


@login_required
def dashboard(request):
    profile, _ = EmployeeProfile.objects.get_or_create(user=request.user)
    # handle product count submission
    today = date.today()
    dailywork, created = DailyWork.objects.get_or_create(employee=profile, date=today)

    if request.method == 'POST':
        if 'product_submit' in request.POST:
            pform = ProductCountForm(request.POST, instance=dailywork)
            if pform.is_valid():
                pform.instance.employee = profile
                pform.instance.date = today
                pform.save()
                messages.success(request, 'Daily product count updated.')
                return redirect('dashboard')
        elif 'clock_in' in request.POST or 'clock_out' in request.POST:
            status = 'IN' if 'clock_in' in request.POST else 'OUT'
            Attendance.objects.create(employee=profile, status=status, marked_by_admin=False)
            messages.success(request, f'Attendance { "clocked in" if status=="IN" else "clocked out" }.')
            return redirect('dashboard')
    else:
        pform = ProductCountForm(instance=dailywork)

    # quick stats
    # number of products today, today's attendance details, last 5 attendances
    product_count = dailywork.product_count
    last_attendances = profile.attendances.order_by('-timestamp')[:8]

    context = {
        'profile': profile,
        'product_count': product_count,
        'pform': pform,
        'last_attendances': last_attendances,
        'today': today,
    }
    return render(request, 'dashboard.html', context)

@login_required
def profile_view(request):
    profile, _ = EmployeeProfile.objects.get_or_create(user=request.user)
    return render(request, 'profile.html', {'profile': profile})

@login_required
def attendance_history(request):
    profile = get_object_or_404(EmployeeProfile, user=request.user)
    attendances = profile.attendances.order_by('-timestamp')
    return render(request, 'attendance_history.html', {'attendances': attendances})

# --------------------------
# Supplier dashboard
# --------------------------
def supplier_logout(request):
    logout(request)  # Logs out the user
    return redirect('index')  # Redirect to the login page