# fms/management/commands/demo_data.py
from django.core.management.base import BaseCommand
from fms.models import Employee, Admin1, Supplier, Product, Attendance, Production
from django.utils import timezone
import random

class Command(BaseCommand):
    help = "Populate the database with demo data"

    def handle(self, *args, **kwargs):
        # Clear old data
        Employee.objects.all().delete()
        Admin1.objects.all().delete()
        Supplier.objects.all().delete()
        Product.objects.all().delete()
        Attendance.objects.all().delete()
        Production.objects.all().delete()

        # Employees
        employees = []
        for i in range(1, 6):
            emp = Employee.objects.create(
                name=f"Employee {i}",
                email=f"emp{i}@example.com",
                position="Staff",
                phone=1000000000 + i,
                salary=20000 + i * 1000,
                password="pass123"
            )
            employees.append(emp)

        # Admins
        for i in range(1, 3):
            Admin1.objects.create(
                name=f"Admin {i}",
                phone=2000000000 + i,
                email=f"admin{i}@example.com",
            )

        # Suppliers
        for i in range(1, 4):
            Supplier.objects.create(
                name=f"Supplier {i}",
                email=f"supplier{i}@example.com",
                phone=3000000000 + i,
                address=f"Address {i}",
                password="supplier123",
                raw_material_name=f"Material {i}"
            )

        # Products
        for i in range(1, 6):
            Product.objects.create(
                name=f"Product {i}",
                price=100 + i * 50
            )

        # Attendance
        today = timezone.now().date()
        for emp in employees:
            for d in range(1, 6):
                Attendance.objects.create(
                    employee=emp,
                    date=today.replace(day=d if d <= 28 else 28),
                    present=random.choice([True, False])
                )

        # Production
        for emp in employees:
            for _ in range(3):
                Production.objects.create(
                    employee=emp,
                    quantity=random.randint(5, 20)
                )

        self.stdout.write(self.style.SUCCESS("Demo data inserted successfully!"))
